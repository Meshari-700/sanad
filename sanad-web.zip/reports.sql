-- ==================================================================
-- سند — إضافة أداة المحاضر
-- تُنفَّذ مرة وحدة بعد schema.sql
-- ==================================================================

-- المحاضر: البيانات المُدخلة + مسار ملف الـ PDF
create table public.reports (
  id            uuid primary key default gen_random_uuid(),
  template_key  text not null check (template_key in ('seizure', 'case_general', 'case_cards')),
  shop_name     text,
  data          jsonb not null default '{}'::jsonb,
  pdf_path      text not null,
  created_by    uuid default auth.uid() references public.profiles(id) on delete set null,
  created_at    timestamptz not null default now()
);

create index on public.reports (created_by, created_at desc);
create index on public.reports (created_at desc);

alter table public.reports enable row level security;

-- المفتش يشوف محاضره فقط، والمشرف/المالك يشوف الكل
create policy reports_select on public.reports for select to authenticated
  using ((created_by = auth.uid() and public.is_active()) or public.is_admin());

-- كل مفتش يضيف باسمه هو فقط
create policy reports_insert on public.reports for insert to authenticated
  with check (created_by = auth.uid() and public.is_active());

-- لا يوجد تعديل (مستند موقّع)، والحذف للمشرف/المالك فقط
create policy reports_delete on public.reports for delete to authenticated
  using (public.is_admin());


-- حافظة خاصة لملفات المحاضر (فيها أسماء وأرقام هويات)
-- المسار: {user_id}/{report_id}.pdf
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('reports', 'reports', false, 15728640, array['application/pdf'])
on conflict (id) do nothing;

create policy reports_storage_select on storage.objects for select to authenticated
  using (
    bucket_id = 'reports'
    and (((storage.foldername(name))[1] = auth.uid()::text and public.is_active()) or public.is_admin())
  );

create policy reports_storage_insert on storage.objects for insert to authenticated
  with check (
    bucket_id = 'reports'
    and (storage.foldername(name))[1] = auth.uid()::text
    and public.is_active()
  );

create policy reports_storage_delete on storage.objects for delete to authenticated
  using (bucket_id = 'reports' and public.is_admin());


-- إضافة الأداة لتبويب الأدوات
insert into public.tools (name, url, icon_type, icon_value, sort_order)
values ('المحاضر', 'app://reports', 'emoji', '📝', coalesce((select max(sort_order) + 1 from public.tools), 0))
on conflict do nothing;
