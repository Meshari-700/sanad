-- ==================================================================
-- سند — سكيما قاعدة البيانات (Supabase / PostgreSQL)
-- تُنفَّذ مرة وحدة على مشروع Supabase جديد من SQL Editor
--
-- التسلسل: مجموعات الأنشطة ← الأنشطة ← الاشتراطات ← البنود (+ صور البند)
-- الأدوار: owner (مالك) / admin (مشرف) / viewer (مفتش)
-- القاعدة: الصلاحية الحقيقية تحكمها RLS هنا، مو الواجهة
-- ==================================================================


-- ==================================================================
-- 1) الحسابات
-- ==================================================================

create table public.profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  email       text,
  full_name   text,
  role        text not null default 'viewer' check (role in ('owner', 'admin', 'viewer')),
  is_disabled boolean not null default false,
  created_at  timestamptz not null default now()
);

-- -------------------------------------------------
-- دوال التحقق من الصلاحية (security definer عشان ما تدخل بحلقة RLS)
-- -------------------------------------------------
create or replace function public.is_active()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and not is_disabled
  );
$$;

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and not is_disabled and role in ('owner', 'admin')
  );
$$;

create or replace function public.is_owner()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and not is_disabled and role = 'owner'
  );
$$;

-- -------------------------------------------------
-- إنشاء صف profiles تلقائيًا عند تسجيل أي مستخدم جديد
-- full_name يُقرأ من signUp(..., { options: { data: { full_name } } })
-- -------------------------------------------------
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, full_name)
  values (
    new.id,
    new.email,
    nullif(trim(new.raw_user_meta_data ->> 'full_name'), '')
  );
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- -------------------------------------------------
-- أي مستخدم يعدّل اسمه هو فقط
-- -------------------------------------------------
create or replace function public.set_my_name(p_name text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_active() then
    raise exception 'الحساب غير مفعّل';
  end if;
  update public.profiles
     set full_name = nullif(trim(p_name), '')
   where id = auth.uid();
end;
$$;

-- -------------------------------------------------
-- تغيير دور مستخدم — owner فقط، وما يقدر يغيّر دوره هو
-- -------------------------------------------------
create or replace function public.set_user_role(target uuid, new_role text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_owner() then
    raise exception 'غير مصرّح';
  end if;
  if target = auth.uid() then
    raise exception 'لا يمكنك تغيير دورك بنفسك';
  end if;
  if new_role not in ('owner', 'admin', 'viewer') then
    raise exception 'دور غير صالح';
  end if;
  update public.profiles set role = new_role where id = target;
end;
$$;

-- -------------------------------------------------
-- تعطيل/تفعيل حساب — owner فقط، وما يقدر يعطّل نفسه
-- -------------------------------------------------
create or replace function public.set_user_disabled(target uuid, disabled boolean)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_owner() then
    raise exception 'غير مصرّح';
  end if;
  if target = auth.uid() then
    raise exception 'لا يمكنك تعطيل حسابك بنفسك';
  end if;
  update public.profiles set is_disabled = disabled where id = target;
end;
$$;

alter table public.profiles enable row level security;

-- كل مستخدم يشوف صفه، والمشرف/المالك يشوف الكل
-- لا توجد سياسة update/insert/delete مباشرة: كل التعديل عبر الدوال أعلاه
create policy profiles_select on public.profiles
  for select to authenticated
  using (id = auth.uid() or public.is_admin());


-- ==================================================================
-- 2) المحتوى التفتيشي
-- icon_type: 'emoji' (icon_value = الإيموجي) أو 'upload' (icon_value = رابط الصورة)
-- ==================================================================

-- مجموعات الأنشطة (للتنظيم والعرض فقط، مثل: أنشطة صحية)
create table public.activity_groups (
  id          uuid primary key default gen_random_uuid(),
  name        text not null,
  icon_type   text not null default 'emoji' check (icon_type in ('emoji', 'upload')),
  icon_value  text,
  sort_order  int  not null default 0,
  created_at  timestamptz not null default now()
);

-- الأنشطة (حذف المجموعة ما يحذف أنشطتها، تصير بدون مجموعة)
create table public.activities (
  id          uuid primary key default gen_random_uuid(),
  group_id    uuid references public.activity_groups(id) on delete set null,
  name        text not null,
  icon_type   text not null default 'emoji' check (icon_type in ('emoji', 'upload')),
  icon_value  text,
  sort_order  int  not null default 0,
  created_at  timestamptz not null default now()
);

-- الاشتراطات (تُعرض منسدلة داخل صفحة النشاط)
create table public.requirements (
  id           uuid primary key default gen_random_uuid(),
  activity_id  uuid not null references public.activities(id) on delete cascade,
  name         text not null,
  sort_order   int  not null default 0,
  created_at   timestamptz not null default now()
);

-- البنود (الصفحة الأخيرة: العنوان، الوصف، الملاحظات، الصور)
create table public.items (
  id              uuid primary key default gen_random_uuid(),
  requirement_id  uuid not null references public.requirements(id) on delete cascade,
  title           text not null,
  description     text,
  notes           text,
  is_suspended    boolean not null default false,
  sort_order      int  not null default 0,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

-- صور البند (حد أقصى 3) — storage_path مسار داخل حافظة item-images
create table public.item_images (
  id            uuid primary key default gen_random_uuid(),
  item_id       uuid not null references public.items(id) on delete cascade,
  storage_path  text not null,
  sort_order    int  not null default 0,
  created_at    timestamptz not null default now()
);

create index on public.activities   (group_id, sort_order);
create index on public.requirements (activity_id, sort_order);
create index on public.items        (requirement_id, sort_order);
create index on public.item_images  (item_id, sort_order);

-- -------------------------------------------------
-- تحديث updated_at تلقائيًا عند تعديل البند
-- -------------------------------------------------
create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger items_touch_updated_at
  before update on public.items
  for each row execute function public.touch_updated_at();

-- -------------------------------------------------
-- فرض حد 3 صور لكل بند (قفل صف البند يمنع تجاوز الحد بالرفع المتزامن)
-- -------------------------------------------------
create or replace function public.enforce_item_images_limit()
returns trigger language plpgsql as $$
begin
  perform 1 from public.items where id = new.item_id for update;
  if (select count(*) from public.item_images where item_id = new.item_id) >= 3 then
    raise exception 'لا يمكن إضافة أكثر من 3 صور للبند';
  end if;
  return new;
end;
$$;

create trigger item_images_limit
  before insert on public.item_images
  for each row execute function public.enforce_item_images_limit();

-- -------------------------------------------------
-- RLS: القراءة لأي حساب مفعّل، الكتابة للمشرف/المالك
-- -------------------------------------------------
alter table public.activity_groups enable row level security;
alter table public.activities      enable row level security;
alter table public.requirements    enable row level security;
alter table public.items           enable row level security;
alter table public.item_images     enable row level security;

create policy activity_groups_select on public.activity_groups for select to authenticated using (public.is_active());
create policy activity_groups_write  on public.activity_groups for all    to authenticated using (public.is_admin()) with check (public.is_admin());

create policy activities_select on public.activities for select to authenticated using (public.is_active());
create policy activities_write  on public.activities for all    to authenticated using (public.is_admin()) with check (public.is_admin());

create policy requirements_select on public.requirements for select to authenticated using (public.is_active());
create policy requirements_write  on public.requirements for all    to authenticated using (public.is_admin()) with check (public.is_admin());

create policy items_select on public.items for select to authenticated using (public.is_active());
create policy items_write  on public.items for all    to authenticated using (public.is_admin()) with check (public.is_admin());

create policy item_images_select on public.item_images for select to authenticated using (public.is_active());
create policy item_images_write  on public.item_images for all    to authenticated using (public.is_admin()) with check (public.is_admin());


-- ==================================================================
-- 3) المفضلة (بنود، محفوظة بحساب المستخدم)
-- "آخر الأنشطة" ما لها جدول — تُحفظ محليًا على الجهاز
-- ==================================================================

create table public.favorites (
  user_id     uuid not null references public.profiles(id) on delete cascade,
  item_id     uuid not null references public.items(id) on delete cascade,
  created_at  timestamptz not null default now(),
  primary key (user_id, item_id)
);

create index on public.favorites (user_id, created_at desc);

alter table public.favorites enable row level security;

-- كل مستخدم يشوف ويضيف ويحذف مفضلته هو فقط
create policy favorites_select on public.favorites for select to authenticated
  using (user_id = auth.uid() and public.is_active());
create policy favorites_insert on public.favorites for insert to authenticated
  with check (user_id = auth.uid() and public.is_active());
create policy favorites_delete on public.favorites for delete to authenticated
  using (user_id = auth.uid() and public.is_active());


-- ==================================================================
-- 4) التوجيهات (+ تتبّع المقروء للنقطة الحمراء بالشريط السفلي)
-- ==================================================================

create table public.directives (
  id          uuid primary key default gen_random_uuid(),
  title       text not null,
  content     text,
  created_by  uuid default auth.uid() references public.profiles(id) on delete set null,
  created_at  timestamptz not null default now()
);

create table public.directive_reads (
  directive_id  uuid not null references public.directives(id) on delete cascade,
  user_id       uuid not null references public.profiles(id) on delete cascade,
  read_at       timestamptz not null default now(),
  primary key (directive_id, user_id)
);

create index on public.directives (created_at desc);

alter table public.directives      enable row level security;
alter table public.directive_reads enable row level security;

create policy directives_select on public.directives for select to authenticated using (public.is_active());
create policy directives_write  on public.directives for all    to authenticated using (public.is_admin()) with check (public.is_admin());

-- المستخدم يسجّل قراءته هو فقط، والمشرف يقدر يشوف إحصائية القراءة
create policy directive_reads_select on public.directive_reads for select to authenticated
  using ((user_id = auth.uid() and public.is_active()) or public.is_admin());
create policy directive_reads_insert on public.directive_reads for insert to authenticated
  with check (user_id = auth.uid() and public.is_active());


-- ==================================================================
-- 5) الأسئلة المتكررة (تصميم مبدئي — يُراجع لما نصمم القسم)
-- ==================================================================

create table public.faqs (
  id          uuid primary key default gen_random_uuid(),
  question    text not null,
  answer      text not null,
  sort_order  int  not null default 0,
  created_at  timestamptz not null default now()
);

alter table public.faqs enable row level security;

create policy faqs_select on public.faqs for select to authenticated using (public.is_active());
create policy faqs_write  on public.faqs for all    to authenticated using (public.is_admin()) with check (public.is_admin());


-- ==================================================================
-- 6) الأدوات
-- url عادي = رابط خارجي أو ملف مرفوع
-- url يبدأ بـ app:// = أداة جاهزة داخل التطبيق (محجوزة للأداة الجديدة)
-- ==================================================================

create table public.tools (
  id          uuid primary key default gen_random_uuid(),
  name        text not null,
  url         text not null,
  icon_type   text not null default 'emoji' check (icon_type in ('emoji', 'upload')),
  icon_value  text,
  is_hidden   boolean not null default false,
  sort_order  int  not null default 0,
  created_at  timestamptz not null default now()
);

-- كل أداة جاهزة (app://...) تُضاف مرة وحدة فقط
create unique index tools_builtin_url_unique on public.tools (url) where url like 'app://%';

alter table public.tools enable row level security;

-- المفتش يشوف الأدوات الظاهرة فقط، المشرف يشوف الكل
create policy tools_select on public.tools for select to authenticated
  using ((public.is_active() and not is_hidden) or public.is_admin());
create policy tools_write on public.tools for all to authenticated
  using (public.is_admin()) with check (public.is_admin());


-- ==================================================================
-- 7) حافظات التخزين (Storage)
-- كلها عامة القراءة (صور مرجعية، بدون بيانات شخصية)، والرفع/الحذف للمشرف فقط
-- مسار صور البند المقترح: {item_id}/{image_id}.jpg
-- ملاحظة: حذف بند من القاعدة ما يحذف ملفاته من التخزين — الكود يحذف الملفات أولًا
-- ==================================================================

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types) values
  ('activity-icons', 'activity-icons', true, 2097152, array['image/jpeg', 'image/png', 'image/webp']),
  ('item-images',    'item-images',    true, 5242880, array['image/jpeg', 'image/png', 'image/webp']),
  ('tool-images',    'tool-images',    true, 2097152, array['image/jpeg', 'image/png', 'image/webp']),
  ('tool-files',     'tool-files',     true, 20971520, null)
on conflict (id) do nothing;

-- سياسة SELECT صريحة (بدونها يفشل الحذف وتبقى ملفات يتيمة)
create policy sanad_storage_select on storage.objects for select
  using (bucket_id in ('activity-icons', 'item-images', 'tool-images', 'tool-files'));

create policy sanad_storage_insert on storage.objects for insert to authenticated
  with check (bucket_id in ('activity-icons', 'item-images', 'tool-images', 'tool-files') and public.is_admin());

create policy sanad_storage_update on storage.objects for update to authenticated
  using (bucket_id in ('activity-icons', 'item-images', 'tool-images', 'tool-files') and public.is_admin())
  with check (bucket_id in ('activity-icons', 'item-images', 'tool-images', 'tool-files') and public.is_admin());

create policy sanad_storage_delete on storage.objects for delete to authenticated
  using (bucket_id in ('activity-icons', 'item-images', 'tool-images', 'tool-files') and public.is_admin());


-- ==================================================================
-- 8) صلاحيات تنفيذ الدوال
-- ==================================================================

revoke execute on function public.set_my_name(text)                from public, anon;
revoke execute on function public.set_user_role(uuid, text)        from public, anon;
revoke execute on function public.set_user_disabled(uuid, boolean) from public, anon;

grant execute on function public.is_active()                        to authenticated;
grant execute on function public.is_admin()                         to authenticated;
grant execute on function public.is_owner()                         to authenticated;
grant execute on function public.set_my_name(text)                  to authenticated;
grant execute on function public.set_user_role(uuid, text)          to authenticated;
grant execute on function public.set_user_disabled(uuid, boolean)   to authenticated;


-- ==================================================================
-- 9) بعد التنفيذ: تعيين أول مالك (مرة وحدة)
-- سجّل حسابك من صفحة التسجيل أولًا، ثم نفّذ هذا السطر ببريدك:
--
--   update public.profiles set role = 'owner' where email = 'your@email.com';
-- ==================================================================
